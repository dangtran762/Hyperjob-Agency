from django.apps import AppConfig


class VacancyConfig(AppConfig):
    name = 'vacancy'
